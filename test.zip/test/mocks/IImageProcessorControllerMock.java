package mocks;

public class IImageProcessorControllerMock {
}
