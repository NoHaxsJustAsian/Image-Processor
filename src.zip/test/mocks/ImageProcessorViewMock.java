package mocks;

import java.io.IOException;

import view.IImageProcessorView;
import view.ImageProcessorView;

public class ImageProcessorViewMock implements IImageProcessorView {
  @Override
  public void renderMessage(String message) throws IOException {

  }
}
